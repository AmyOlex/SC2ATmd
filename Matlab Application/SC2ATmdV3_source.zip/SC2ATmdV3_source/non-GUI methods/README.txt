These methods were re-designed to perform the same analysis as the GUI version, but with only text output and no image output.  They must be used from the command-line interface.



Last updated 12/7/2007 by Amy Olex